public class Path{

    protected Graphe graphe;

    public Path(Graphe g){
        this.graphe=g;
        this.addFin();
    }

    private void addFin(){
        Neux fin=new Fin();
        for(Neux n1:this.graphe.toTab()){
            int i=0;
            boolean trouve=false;
            while(!trouve && i<graphe.toTab().length){
                int j=0;
                while (!trouve && j<this.graphe.toTab()[i].getPrecede().length){
                    if(n1==this.graphe.toTab()[i].getPrecede()[j]){
                        trouve=true;
                    }
                    j++;
                }
                i++;
            }
            if(!trouve){
                fin.addPre(n1);
            }
        }
        this.graphe.addNeux(fin);
    }

    private void ASAP(){
        this.graphe.toTab()[(this.graphe.toTab().length-1)].ASAP();
    }

    private void ALAP(){
        for(Neux n:this.graphe.toTab()){
            if(n.getPrecede().length==0){
                n.ALAP(dayFin());
            }
        }
    }

    public void go(){
        this.ASAP();
        this.ALAP();
    }

    public int dayFin(){
        return this.graphe.toTab()[this.graphe.toTab().length-1].getDepareTo();
    }

}