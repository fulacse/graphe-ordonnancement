class Principal{

    public static void main(String[] arg){

        Graphe g1=new Graphe();
        Neux a=new Neux('A',10);
        g1.addNeux(a);
        Neux b=new Neux('B',5,g1);
        Neux c=new Neux('C',1,g1);
        Neux d=new Neux('D',3,g1);
        g1.addArc(a,c);
        g1.addArc(b,c);
        g1.addArc(a,d);
        Path p1=new Path(g1);
        p1.go();
        for(Neux n:p1.graphe.neuxs.toTab()){
            System.out.println(n+"\n=========================");
        }

    }

}